import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailview',
  templateUrl: './detailview.component.html',
  styleUrls: ['./detailview.component.css']
})
export class DetailviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
